package Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.gestionDB;

/**
 * Servlet implementation class LoginConnexionServlet
 */
@WebServlet("/LoginConnexionServlet")
public class LoginConnexionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	gestionDB gdb;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginConnexionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("GET");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Login : " + request.getParameter("login"));
		
		String login=  request.getParameter("login");
		String mpasse = request.getParameter("passe");
		HttpSession session = request.getSession() ;
		session.setAttribute("choixSession", login) ;
		String sql=null;
		gdb = new gestionDB();
		//sql="insert into connexion(login, mpasse)values('"+login+"','"+mpasse+"')";
		sql="select * from connexion where login='"+login+"' and mpasse='"+mpasse+"'";
		System.out.println(sql);
		gdb.setSql(sql);
		gdb.selectFromDB();
		
		RequestDispatcher dispatcher;
		if(gdb.sizeSelectDB() == 1){
            dispatcher = request.getRequestDispatcher("/Session.jsp");
        }else{
        	request.setAttribute("message", login);
            dispatcher = request.getRequestDispatcher("/LoginConnexion.jsp");
            
        }
        dispatcher.forward(request, response);
        }
		
		
	

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.service(arg0, arg1);
	}

}
