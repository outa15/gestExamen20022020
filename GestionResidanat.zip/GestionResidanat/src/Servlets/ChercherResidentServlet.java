package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.Resident;
import Models.ResidentBDD;

/**
 * Servlet implementation class DetailResidentServlet
 */
@WebServlet("/ChercherResidentServlet")
public class ChercherResidentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChercherResidentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		    String id = request.getParameter("pid");
		    String critereRecherche = request.getParameter("criterReche");
		    String session = request.getParameter("session");
		    
		    String user="root";
			 String pass="";
			 String url="jdbc:mysql://localhost:3306/gestionprojet";
			 //HttpSession sessionLibe = request.getSession(); 
			
		    ResidentBDD list = new ResidentBDD(url,user,pass);
		    List<Resident> listRes = null ;
		    try {
		    	listRes = list.getResidentCritere(id,critereRecherche,session);
			} catch (SQLException e) {
				e.getMessage();
			}
			request.setAttribute("listDetail", listRes);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AfficherDetailRecherche.jsp");
			dispatcher.forward(request, response);
		
	}

}
