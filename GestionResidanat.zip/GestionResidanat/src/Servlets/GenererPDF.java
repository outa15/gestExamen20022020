package Servlets;


import java.awt.Event;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
 
import Models.Resident;
import Models.ResidentBDD;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Header;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;


/**
 * Servlet implementation class GenererPDF
 */
@WebServlet("/GenererPDF")
public class GenererPDF extends HttpServlet   {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenererPDF() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Hello Geneart pdf");
		
		//get the output stream for writing binary data in the response.
		  ServletOutputStream os = response.getOutputStream();
		  
		  //set the response content type to PDF
		  response.setContentType("application/pdf"); 
		  //create a new document
		  Document doc = new Document(PageSize.A4, 40, 40, 20, 20);
		  try {
			PdfWriter.getInstance(doc, os);
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
			doc.open();  
		 
		
		
		
		  String filename = "C:/Users/Tayab/workspace/GestionResidanat/img/Header.PNG";
		  Image image;
		try {
			image = Image.getInstance(filename);
			image.scaleAbsolute(540f, 150f);
       
			doc.add(image);
		}  catch ( IOException e) {
            e.printStackTrace();
        } 
		catch (DocumentException  e) {
			 e.printStackTrace();
		}
		
	      
		// Titre
		Font bfBold18 = new Font(FontFamily.TIMES_ROMAN, 24, Font.UNDERLINE, new BaseColor(0, 0, 0));
		try {
			Paragraph parag = new Paragraph(" ATTESTATION D�INSCRIPTION ", bfBold18);
			parag.setLeading(60);
			parag.setAlignment(Paragraph.ALIGN_CENTER);
			doc.add(parag );
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Font bfBold14 = new Font(FontFamily.TIMES_ROMAN, 14);
		
		Paragraph parag2 = new Paragraph("Le Doyen  de la Facult� de M�decine et de Pharmacie D�Oujda, soussign�, atteste que : ", bfBold14);
		parag2.setLeading(70);
		try {
			doc.add(parag2 );
		} catch (DocumentException e) {
			
			e.printStackTrace();
		}
		 HttpSession sessionLibe = request.getSession();
		 System.out.println("cin = "+sessionLibe.getAttribute("CIN"));
		 
			  String user="root";
				 String pass="";
				 String url="jdbc:mysql://localhost:3306/gestionprojet";
			    ResidentBDD list = new ResidentBDD(url,user,pass);
			    Resident listRes = null ;
			    try {
			    	listRes = list.getResident((String)sessionLibe.getAttribute("CIN"));
				} catch (SQLException e) {
					e.getMessage();
				}
	if(listRes != null){
		try {
			Paragraph parag3 = new Paragraph("Le Docteur        :  " + listRes.getNom().trim().toUpperCase() + " " +listRes.getPrenom().trim(), bfBold14);
			parag3.setLeading(70);
			doc.add( parag3);
			Paragraph parag4 = new Paragraph("N� (e) le		            :  " + listRes.getDateNaissance() + " � " +listRes.getLieuaissance(), bfBold14);
			parag4.setLeading(30);
			doc.add( parag4);
			Paragraph parag5 = new Paragraph("Nationalit�   	     :  " + listRes.getNationalite(), bfBold14);
			parag5.setLeading(30);
			doc.add( parag5);
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
			    date = dateFormat.parse(listRes.getAnnee());
			    System.out.println("Date pars�e : "+date);
			} catch (Exception e) {
			    System.err.println("Format de date invalide. Usage : yyyy-MM-dd");
			    System.err.println(e.getMessage());
			}
			Date dateJr = new Date();
			int year = date.getYear() - dateJr.getYear() ;
			System.out.print("Year "+year);
			String yearString;
			if(year == 0) yearString = 1+"�re";
			else yearString = year +"�me";
			Paragraph parag6 = new Paragraph("Est M�decin�R�sident (e), sp�cialit� "+ listRes.getSpecialite() + ", au centre Hospitalier Universitaire Mohammed VI d�Oujda. Il (elle) est inscrit (e) en "+ yearString +" ann�e de R�sidanat depuis le "+listRes.getAnnee() +", et ce pour une dur�e de Formation de "+listRes.getDureeFormation()+".", bfBold14);
			parag6.setLeading(30);
			doc.add(parag6); 
			Paragraph parg8 =  new Paragraph("Cette attestation est d�livr�e � l�int�ress� (e) pour servir et valoir ce que de droit.", bfBold14);
			parg8.setLeading(60);
			doc.add(parg8);
			
			
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		
		  String filenameFooter = "C:/Users/Tayab/workspace/GestionResidanat/img/footer.PNG";
		  Image imageFooter;
		try {
			imageFooter = Image.getInstance(filenameFooter);
			imageFooter.scaleAbsolute(540f, 210f);
			//imageFooter.setLeft(90);
			doc.add(imageFooter);
		}  catch ( IOException e) {
            e.printStackTrace();
        } 
		catch (DocumentException  e) {
			 e.printStackTrace();
		}
		
    }


	
	
	
		 doc.close(); 
		 }
	
	
}
