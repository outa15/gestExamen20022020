package Servlets;



import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.PageContext;

import com.mysql.jdbc.ResultSet;
import Models.gestionDB;

/**
 * Servlet implementation class SessionServlet
 */
@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	gestionDB gdb;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
System.out.println("libelle : " + request.getParameter("libelle"));
		
		String libelle=  request.getParameter("libelle");
		String dateDebut=  request.getParameter("debut");
		String sql=null,sqlInsrt = null;
		gdb = new gestionDB();
		
		sql="select * from session where libellesession = '"+libelle+"'";
		gdb.setSql(sql);
		gdb.selectFromDB();
		String messageRet ;
		if(gdb.sizeSelectDB() == 0)
		{
			sqlInsrt="insert into session(libellesession,datedebut)values('"+libelle+"','"+dateDebut+"')";
			gdb.setSql(sqlInsrt);
			try {
				gdb.updateDB();
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
			}
			messageRet = "La session '"+libelle+"' ajoutée";
		}
		else {
			messageRet = "La session '"+libelle+"' existe déja ! ";
		}
		
		
		request.setAttribute("message", messageRet);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/Session.jsp");
		dispatcher.forward(request, response);
	}

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {
		System.out.println("jjdjd");
		super.service(arg0, arg1);
	}
	
	

}
