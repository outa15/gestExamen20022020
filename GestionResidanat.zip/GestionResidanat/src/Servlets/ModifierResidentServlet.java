package Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.gestionDB;

/**
 * Servlet implementation class ModifierResidentServlet
 */
@WebServlet("/ModifierResidentServlet")
public class ModifierResidentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	gestionDB gdb;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModifierResidentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
String sql=null;
		gdb = new gestionDB();
		String cin=req.getParameter("cin");
		String cne =req.getParameter("cne");
		String nom=req.getParameter("nom");
		String prenom=req.getParameter("prenom");
		String dateNaiss = req.getParameter("dateNaiss");
		String nationalite = req.getParameter("nationalite");
		String tel = req.getParameter("tel");
		String annee = req.getParameter("annee");

		String statut  = req.getParameter("statut");
		String specialite  = req.getParameter("specialite");
		String note  = req.getParameter("note");
		int noteInteger = Integer.parseInt(note);
		sql="update resident set Nom = '"+nom+"', Prenom ='"+prenom+"',CIN ='"+cin+"',CNE = '"+cne+"', DateNaissance = '"+dateNaiss+"' , Nationalite ='"+nationalite+"', Tel = '"+tel+"', Annee = '"+annee+"',Statut = '"+statut+"', Specialite = '"+specialite+"',Note = "+noteInteger+" where CIN='"+cin+"'";
			
		System.out.println(sql);
		gdb.setSql(sql);
		try {
			gdb.updateDB();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		RequestDispatcher dispatcher;
		HttpSession session = req.getSession();
		System.out.println("Choix = "+req.getParameter("choix") +" Session = "+session.getAttribute("idSess"));
		if("update".equals(req.getParameter("choix"))){
            dispatcher = req.getRequestDispatcher("/AfficherListeResident.jsp?id="+session.getAttribute("idSess")+"");
            System.out.println("/AfficherListeResident.jsp?id='"+session.getAttribute("idSess")+"'");
            }
		else
			{
			dispatcher = req.getRequestDispatcher("/AffichageResident.jsp");
			System.out.println("/AffichageResident.jsp");
			}
        dispatcher.forward(req, response);
        }
	

}
