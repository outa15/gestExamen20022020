package Servlets;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.ResultSet;

import Models.gestionDB;


/**
 * Servlet implementation class AffichageResidentServlet
 */
@WebServlet("/AffichageResidentServlet")
public class AffichageResidentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	gestionDB gdb;
@SuppressWarnings("unchecked")
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	gestionDB gdb=new gestionDB();
	HashMap perso;
	String sql=null;
	
	 if(req.getParameter("idPrs")!=null && req.getParameter("choix")!=null) {
    	 
    	 if(req.getParameter("choix").equals("update")) {
    		 System.out.println("update");

    	 int idPrs=Integer.parseInt(req.getParameter("idPrs"));
    	 //System.out.println("Id personne="+idPrs);
    	 
    	 ArrayList prs=new ArrayList();
    	 try {
    		 sql="select * from Personnel where id='"+idPrs+"'";
        	 gdb.setSql(sql);
        	 ResultSet personne = gdb.selectFromDB();
        	 
    		 while(personne.next()) {
					
				 perso =new HashMap();
				
				 perso.put("Nom",personne.getString("Nom"));
				 perso.put("Prenom",personne.getString("Prenom"));
				 perso.put("CIN",personne.getString("CIN"));
				 perso.put("id",personne.getString("id")); 
				 
				 prs.add(perso);	
			 }
    	 }catch(SQLException e) {
    		 e.printStackTrace();
    	 }
    	 req.setAttribute("prs", prs);
     }else {
    	 if(req.getParameter("choix").equals("delete")) {
    		 System.out.println("delete");
    		 int idPrs=Integer.parseInt(req.getParameter("idPrs").toString());
    		 sql="delete from personnel where id='"+idPrs+"'";
    		 try {
    			 gdb.setSql(sql);
    			 gdb.updateDB();
    		 }catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	 }
     }
     }
	
	
	// Select le résident ajouté
	
	         String cin = req.getParameter("cin");
			 sql= "select * from resident where CIN='"+cin+"'" ;
		     gdb.setSql(sql);
		     ResultSet Resultat =gdb.selectFromDB();
		     ArrayList ListeResultat = new ArrayList();
		    
		          
		         try {
					while(Resultat.next()) {
						
						 perso =new HashMap();
						 perso.put("Nom",Resultat.getString("Nom"));
						 perso.put("Prenom",Resultat.getString("Prenom"));
						 perso.put("CIN",Resultat.getString("CIN"));
						 perso.put("CNE",Resultat.getString("CNE")); 
						 perso.put("DateNaissance",Resultat.getString("DateNaissance")); 
						 perso.put("Nationalite",Resultat.getString("Nationalite")); 
						 perso.put("Tel",Resultat.getString("Tel")); 
						 perso.put("Annee",Resultat.getString("Annee")); 
						 perso.put("Statut",Resultat.getString("Statut")); 
						 perso.put("Specialite",Resultat.getString("Specialite")); 
						 perso.put("Note",Resultat.getString("Note")); 
						 perso.put("Duree",Resultat.getString("Duree"));
						 perso.put("LieuNaissance",Resultat.getString("LieuNaissance"));
						 
						 ListeResultat.add(perso);	
					 }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		     
		         req.setAttribute("listePersonne",ListeResultat );
	
		        
	
	 req.getRequestDispatcher("/AffichageResident.jsp").forward(req, resp);
    

	}


@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	String sql=null;
	gdb=new gestionDB();
		if(req.getParameter("choix")!=null) {
	
	String choix=req.getParameter("choix");
	
	if(choix.equals("add")) {
	String cin=req.getParameter("cin");
	String cne =req.getParameter("cne");
	String nom=req.getParameter("nom");
	String prenom=req.getParameter("prenom");
	String datenaissance =req.getParameter("dateNaiss");
	String nationalite=req.getParameter("nationalite");
	 
	String tel=req.getParameter("tel");
	String annee =req.getParameter("annee");
	String statut=req.getParameter("statut");
	String specialite =req.getParameter("specialite");
	String note=req.getParameter("note");
	String idSession = req.getParameter("session");
	String duree = req.getParameter("dureeSpec");
	String lieuNaissance = req.getParameter("lieuNaissance");
	
	String sousspecialite = req.getParameter("sousspecialite");
	sql ="select * from resident where CIN='"+cin+"'" ;
	System.out.println(sql);
	gdb.setSql(sql);
	ResultSet resident = gdb.selectFromDB();
	if(resident != null){
	try {
		resident.last();
		int  size = resident.getRow();
		if(size == 1 )
		{
			 req.setAttribute("messageInfo","Ce r�sident existe d�ja => " );
		}
		else {
			sql="INSERT INTO resident(id_FKsession, Nom, Prenom, CIN, CNE, DateNaissance, Nationalite, Tel, Annee, Statut,Specialite, Note, Duree,LieuNaissance,SousSpec) VALUES ('"+idSession+"','"+nom+"','"+prenom+"','"+cin+"','"+cne+"','"+datenaissance+"','"+nationalite+"','"+tel+"','"+annee+"','"+statut+"','"+specialite+"','"+note+"','"+duree+"','"+lieuNaissance+"','"+sousspecialite+"')";
			System.out.println("Requete insertion "+sql);
			gdb.setSql(sql);
			try {
				gdb.updateDB();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	} catch (SQLException e2) {
		e2.printStackTrace();
	}  } 
	
	}
	doGet(req, resp);
		}
	}

} 