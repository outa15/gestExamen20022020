package Models;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.mysql.jdbc.Driver;
public class gestionDB {

	private String sql=null;
	private String user="root";
	private String pass="";
	private String url="jdbc:mysql://localhost:3306/gestionprojet";
	
	public ResultSet resultat;
	Connection cnx=null;
	Statement st=null;
	
	public void setSql(String sql){
		this.sql=sql;
	}
private void setConnexion() throws ClassNotFoundException{
		
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			cnx=(Connection)DriverManager.getConnection(url, user, pass);
			System.out.println("Connexion etablie");
			
			
		}catch(SQLException e){
			e.printStackTrace();
			System.out.print("Echec");
			
			
			System.out.println(e);
		}
		
	}
	public ResultSet selectFromDB(){

		try{
			setConnexion();
			st=(Statement)cnx.createStatement();
			resultat=(ResultSet)st.executeQuery(sql);
		}catch(Exception e){
			System.out.println("Erreur");
	
		}
		return resultat;
		
	}
	/**
	 * 
	 * @return
	 */
	public int sizeSelectDB(){
		int size = 0;
		try{
			setConnexion();
			st=(Statement)cnx.createStatement();
			resultat=(ResultSet)st.executeQuery(sql);
			resultat.last();
			size = resultat.getRow();
			
		}catch(Exception e){
			System.out.println("Erreur");
	
		}
		return size;
		
	}
	public void closeConnexion(){
		try{
			if(cnx!=null) {
			cnx.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	public void updateDB() throws ClassNotFoundException{
		try{
			setConnexion();
			st=(Statement)cnx.createStatement();
			
			st.executeUpdate(sql);
			closeConnexion();
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println("Erreur");
			System.out.print("EchecccccccCCcccc");
		}
	}
	
	
	
}
