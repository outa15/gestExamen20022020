package Models;

public class Resident {

	protected int id;
    protected String CIN;
    protected String CNE;
    protected String Nom;
    protected String Prenom;
    protected String dateNaissance;
    protected String nationalite;
    protected String tel;
    protected String annee;
    protected String statut;
    protected String specialite;
    protected String note;
    protected String dureeFormation;
    protected String lienaissance;
    
    protected String SousSpec;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCIN() {
		return CIN;
	}
	public void setCIN(String cIN) {
		CIN = cIN;
	}
	public String getCNE() {
		return CNE;
	}
	public void setCNE(String cNE) {
		CNE = cNE;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		Prenom = prenom;
	}
	public String getDateNaissance() {
		return dateNaissance;
	}
	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	public String getNationalite() {
		return nationalite;
	}
	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAnnee() {
		return annee;
	}
	public void setAnnee(String annee) {
		this.annee = annee;
	}
	public String getStatut() {
		return statut;
	}
	public void setStatut(String statut) {
		this.statut = statut;
	}
	public String getSpecialite() {
		return specialite;
	}
	public void setSpecialite(String specialite) {
		this.specialite = specialite;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getDureeFormation() {
		return dureeFormation;
	}
	public void setDureeFormation(String dureeFormation) {
		this.dureeFormation = dureeFormation;
	}
	public String getLieuaissance() {
		return lienaissance;
	}
	public void setLieuaissance(String lieuaissance) {
		this.lienaissance = lieuaissance;
	}
	public String getLienaissance() {
		return lienaissance;
	}
	public void setLienaissance(String lienaissance) {
		this.lienaissance = lienaissance;
	}
	
	public String getSousSpec() {
		return SousSpec;
	}
	public void setSousSpec(String sousSpec) {
		SousSpec = sousSpec;
	}
	public Resident(String cIN, String cNE, String nom, String prenom,
			String dateNaissance, String nationalite, String tel, String annee,
			String statut, String specialite, String note,
			String dureeFormation, String lienaissance,	String sousSpec) {
		super();
		CIN = cIN;
		CNE = cNE;
		Nom = nom;
		Prenom = prenom;
		this.dateNaissance = dateNaissance;
		this.nationalite = nationalite;
		this.tel = tel;
		this.annee = annee;
		this.statut = statut;
		this.specialite = specialite;
		this.note = note;
		this.dureeFormation = dureeFormation;
		this.lienaissance = lienaissance;
		
		SousSpec = sousSpec;
	}
	
	
    
}
