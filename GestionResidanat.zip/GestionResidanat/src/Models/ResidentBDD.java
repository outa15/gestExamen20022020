package Models;

import java.sql.SQLException;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class ResidentBDD {
	  private String jdbcURL;
	    private String jdbcUsername;
	    private String jdbcPassword;
	    private com.mysql.jdbc.Connection jdbcConnection;
	     
	    public ResidentBDD(String jdbcURL, String jdbcUsername, String jdbcPassword) {
	        this.jdbcURL = jdbcURL;
	        this.jdbcUsername = jdbcUsername;
	        this.jdbcPassword = jdbcPassword;
	    }
	     
	    protected void connect() throws SQLException {
	        if (jdbcConnection == null || jdbcConnection.isClosed()) {
	            try {
	                Class.forName("com.mysql.jdbc.Driver");
	            } catch (ClassNotFoundException e) {
	                throw new SQLException(e);
	            }
	            jdbcConnection = (Connection) DriverManager.getConnection(
	                                        jdbcURL, jdbcUsername, jdbcPassword);
	        }
	    }
	     
	    protected void disconnect() throws SQLException {
	        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
	            jdbcConnection.close();
	        }
	    }
	     
	    public boolean insertResident(Resident Resident) throws SQLException {
	        String sql = "INSERT INTO Resident (title, author, price) VALUES (?, ?, ?)";
	        connect();
	         
	        java.sql.PreparedStatement statement = jdbcConnection.prepareStatement(sql);
//	        statement.setString(1, Resident.getTitle());
//	        statement.setString(2, Resident.getAuthor());
//	        statement.setString(3, Resident.getPrice());
	         
	        boolean rowInserted = statement.executeUpdate() > 0;
	        statement.close();
	        disconnect();
	        return rowInserted;
	    }
	     /*
	      * 
	      */
	    public List<Resident> listAllResidents(String idSession) throws SQLException {
	        List<Resident> listResident = new ArrayList<Resident>();
	         
	        String sql = "SELECT * FROM resident where id_FKsession= '"+idSession+"'";
	         
	        connect();
	         System.out.println(sql);
	        com.mysql.jdbc.Statement statement = (Statement) jdbcConnection.createStatement();
	        ResultSet resultSet = (ResultSet) statement.executeQuery(sql);
	         
	        while (resultSet.next()) {
	            
	        	String cIN = resultSet.getString("CIN");
	            String cNE = resultSet.getString("CNE");
	            String nom = resultSet.getString("Nom");
	            String prenom = resultSet.getString("Prenom");
	            String dateNaissance = resultSet.getString("DateNaissance");
	            String nationalite = resultSet.getString("Nationalite");
	            String tel = resultSet.getString("Tel");
	            String annee = resultSet.getString("Annee");
	        	String statut = resultSet.getString("Statut");
	        	String specialite = resultSet.getString("Specialite");
	        	String note  = resultSet.getString("Note");
	        	String dure  = resultSet.getString("Duree");
	        	String lieuNais = resultSet.getString("LieuNaissance");
	        	
	        	String SousSpec = resultSet.getString("SousSpec");
	        	Resident Resident = new Resident( cIN,  cNE,  nom,  prenom,
	        			 dateNaissance,  nationalite,  tel,  annee,
	        			 statut,  specialite,  note,dure,lieuNais,SousSpec);
	             
	            
	            listResident.add(Resident);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        disconnect();
	         
	        return listResident;
	    }
	     
	    public boolean deleteResident(String pCINresident) throws SQLException {
	        String sql = "DELETE FROM Resident where CIN = ?";
	         
	        connect();
	         
	        PreparedStatement statement = (PreparedStatement) jdbcConnection.prepareStatement(sql);
	        statement.setString(1, pCINresident);
	         
	        boolean rowDeleted = statement.executeUpdate() > 0;
	        statement.close();
	        disconnect();
	        return rowDeleted;     
	    }
	     
	    public boolean updateResident(Resident Resident) throws SQLException {
	        String sql = "UPDATE Resident SET title = ?, author = ?, price = ?";
	        sql += " WHERE Resident_id = ?";
	        connect();
	         
	        PreparedStatement statement = (PreparedStatement) jdbcConnection.prepareStatement(sql);
	        statement.setString(1, Resident.getCIN());
	        statement.setString(2, Resident.getNom());
	        statement.setString(3, Resident.getPrenom());
	        // TODO
	        statement.setInt(4, Resident.getId());
	         
	        boolean rowUpdated = statement.executeUpdate() > 0;
	        statement.close();
	        disconnect();
	        return rowUpdated;     
	    }
	    public List<Resident> getResidentCritere(String id,String critere,String session) throws SQLException {
	    	
	        String sql = "SELECT * FROM Resident WHERE " +critere+ " = '"+id+"' AND id_FKsession = '"+session+"'";
	        System.out.println(sql);
	        List<Resident> listeRetourn = new ArrayList<Resident>();
	        connect();
	        PreparedStatement statement = (PreparedStatement) jdbcConnection.prepareStatement(sql);

	        ResultSet resultSet = (ResultSet) statement.executeQuery();
	         
	        while (resultSet.next()) {
	        	Resident Resident = null;
	        	String cIN = resultSet.getString("CIN");
	            String cNE = resultSet.getString("CNE");
	            String nom = resultSet.getString("Nom");
	            String prenom = resultSet.getString("Prenom");
	            String dateNaissance = resultSet.getString("DateNaissance");
	            String nationalite = resultSet.getString("Nationalite");
	            String tel = resultSet.getString("Tel");
	            String annee = resultSet.getString("Annee");
	        	String statut = resultSet.getString("Statut");
	        	String specialite = resultSet.getString("Specialite");
	        	String note  = resultSet.getString("Note");
	        	String dure  = resultSet.getString("Duree");
	        	String lieuNais = resultSet.getString("LieuNaissance");
	        	String SousSpec = resultSet.getString("SousSpec");
	            Resident = new Resident( cIN,  cNE,  nom,  prenom,
	        			 dateNaissance,  nationalite,  tel,  annee,
	        			 statut,  specialite,  note,dure,lieuNais,SousSpec);
	            listeRetourn.add(Resident);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        return listeRetourn;
	    }
	    public Resident getResident(String id) throws SQLException {
	    	Resident Resident = null;
	        String sql = "SELECT * FROM Resident WHERE CIN = ?";
	         
	        connect();
	         
	        PreparedStatement statement = (PreparedStatement) jdbcConnection.prepareStatement(sql);
	        statement.setString(1, id);
	         
	        ResultSet resultSet = (ResultSet) statement.executeQuery();
	         
	        if (resultSet.next()) {
	           
	        	String cIN = resultSet.getString("CIN");
	            String cNE = resultSet.getString("CNE");
	            String nom = resultSet.getString("Nom");
	            String prenom = resultSet.getString("Prenom");
	            String dateNaissance = resultSet.getString("DateNaissance");
	            String nationalite = resultSet.getString("Nationalite");
	            String tel = resultSet.getString("Tel");
	            String annee = resultSet.getString("Annee");
	        	String statut = resultSet.getString("Statut");
	        	String specialite = resultSet.getString("Specialite");
	        	String note  = resultSet.getString("Note");
	        	String dure  = resultSet.getString("Duree");
	        	String lieuNais = resultSet.getString("LieuNaissance");
	        	String SousSpec = resultSet.getString("SousSpec");
	            Resident = new Resident( cIN,  cNE,  nom,  prenom,
	        			 dateNaissance,  nationalite,  tel,  annee,
	        			 statut,  specialite,  note,dure,lieuNais,SousSpec);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        return Resident;
	    }
        
	   
	    public List<String> getAllSpecialiteCriter() throws SQLException {
	    	
	        String sql = "SELECT * FROM Sousspecialite " ;
	         
	        connect();
	         
	        PreparedStatement statement = (PreparedStatement) jdbcConnection.prepareStatement(sql);
	       
	         
	        ResultSet resultSet = (ResultSet) statement.executeQuery();
	         List<String> listeSpec = new ArrayList<String>();
	        while (resultSet.next()) {
	           
	        	listeSpec.add(resultSet.getString("libellesousspeci"));
	        
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        return listeSpec;
	    }
	    public List<String> getAllSpecialite() throws SQLException {
	    	
	        String sql = "SELECT * FROM Specialite";
	         
	        connect();
	         
	        PreparedStatement statement = (PreparedStatement) jdbcConnection.prepareStatement(sql);
	       
	         
	        ResultSet resultSet = (ResultSet) statement.executeQuery();
	         List<String> listeSpec = new ArrayList<String>();
	        while (resultSet.next()) {
	           
	        	listeSpec.add(resultSet.getString("libelleSpecialite"));
	        
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        return listeSpec;
	    }
}
